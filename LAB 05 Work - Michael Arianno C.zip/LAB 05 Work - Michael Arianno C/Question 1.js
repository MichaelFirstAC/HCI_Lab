let num = 11;
while (num <= 40) {
    console.log(num);
    num += 2;
}

for (let i = 11; i <= 40; i += 2) {
    console.log(i);
}

