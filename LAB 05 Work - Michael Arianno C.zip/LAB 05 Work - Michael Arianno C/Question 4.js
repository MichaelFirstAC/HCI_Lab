function isUniform(arr) {
    const firstElement = arr[0];
    return arr.every(element => element === firstElement);
}

// Example usage:
console.log(isUniform([1, 1, 1, 1]));  // Output: true
console.log(isUniform([1, 2, 1, 1]));  // Output: false
